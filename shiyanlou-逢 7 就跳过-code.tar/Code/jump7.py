for x in range(1,100):
	if x%7==0 and x%10==7 and a//7:
		continue
	print(x)